
# Alyabot - WhatsApp Toxic + Romantic Bot

## 🚀 Deploy to Railway

1. Fork or upload this to GitHub.
2. Go to [Railway](https://railway.app/), create new project → GitHub repo.
3. In **Variables**:
   - Key: `OPENAI_API_KEY`
   - Value: `your_openai_key`

4. Scan QR to generate `session` folder locally.
5. Upload `session` folder (only `session.json`) to the GitHub repo.

## ✅ Start Script

```
npm install
npm start
```
